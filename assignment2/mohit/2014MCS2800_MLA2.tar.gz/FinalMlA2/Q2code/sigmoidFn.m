function  s  = sigmoidFn(t)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
s = 1 / (1 + exp(-1*t));

end

